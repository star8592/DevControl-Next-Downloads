# User-session supervisor for the same devcontrol-agent binary/protocol as Linux.
param([Parameter(Mandatory=$true)][string]$InstallRoot)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$pointer = Join-Path $InstallRoot 'current.json'
$config = Get-Content -LiteralPath $pointer -Raw | ConvertFrom-Json
if ($config.schema -ne 'devcontrol-next.windows-agent.v1' -or $config.release -notmatch '^[A-Za-z0-9._-]+$') {
    throw 'Invalid active Windows Agent release pointer.'
}
$releaseDir = Join-Path $InstallRoot (Join-Path 'releases' $config.release)
$binary = Join-Path $releaseDir 'bin\devcontrol-agent.exe'
if (-not (Test-Path -LiteralPath $binary -PathType Leaf)) { throw 'Agent binary is unavailable.' }
$env:DEVCONTROL_NEXT_AGENT_NAMESPACE = 'devcontrol-next-staging'
$env:DEVCONTROL_NEXT_LOCAL_AUTH_BIND = '127.0.0.1:28789'
$env:DEVCONTROL_NEXT_AGENT_STATE_DIR = Join-Path $InstallRoot 'state'
$env:DEVCONTROL_NEXT_COMPONENT_ROOT = Join-Path $releaseDir 'components'
$env:DEVCONTROL_NEXT_SECURITY_MODE = 'guarded'
$env:DEVCONTROL_NEXT_WRITE_ROOTS = ''
Set-Location -LiteralPath $releaseDir
& $binary run --gateway $config.gateway
exit $LASTEXITCODE
