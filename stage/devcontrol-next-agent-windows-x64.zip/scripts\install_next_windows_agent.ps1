# DevControl Next Windows Agent: per-user CLI installation (Windows PowerShell 5.1+).
# No UAC elevation, UI wizard, persisted enrollment token, or additional MCP tools.
[CmdletBinding(DefaultParameterSetName = 'Install')]
param(
    [Parameter(ParameterSetName='Install', Mandatory=$true)]
    [string]$PackageDir,
    [Parameter(ParameterSetName='Install')]
    [string]$GatewayUrl = 'https://mcpx.devcontrol.dev',
    [Parameter(ParameterSetName='Install')]
    [switch]$DevelopmentUnsigned,
    [Parameter(ParameterSetName='Status', Mandatory=$true)]
    [switch]$Status,
    [Parameter(ParameterSetName='Uninstall', Mandatory=$true)]
    [switch]$Uninstall,
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'devcontrol-next\Agent')
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$taskName = 'DevControlNext-Agent'
if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) {
    throw 'This installer only runs on Windows.'
}
if (-not [Environment]::Is64BitOperatingSystem) {
    throw 'Windows x64 is required for this package.'
}
$InstallRoot = [IO.Path]::GetFullPath($InstallRoot)
$pointer = Join-Path $InstallRoot 'current.json'
$stateDir = Join-Path $InstallRoot 'state'

function Lock-PrivateDirectory([string]$Path) {
    [IO.Directory]::CreateDirectory($Path) | Out-Null
    $acl = New-Object System.Security.AccessControl.DirectorySecurity
    $acl.SetAccessRuleProtection($true, $false)
    $owner = [Security.Principal.WindowsIdentity]::GetCurrent().User
    $system = [Security.Principal.SecurityIdentifier]::new('S-1-5-18')
    foreach ($principal in @($owner, $system)) {
        $rule = [Security.AccessControl.FileSystemAccessRule]::new(
            $principal, [Security.AccessControl.FileSystemRights]::FullControl,
            [Security.AccessControl.InheritanceFlags]'ContainerInherit,ObjectInherit',
            [Security.AccessControl.PropagationFlags]::None,
            [Security.AccessControl.AccessControlType]::Allow
        )
        $acl.AddAccessRule($rule)
    }
    [IO.Directory]::SetAccessControl($Path, $acl)
}
function Verify-Package([string]$Source) {
    $Source = [IO.Path]::GetFullPath($Source)
    $manifest = Join-Path $Source 'SHA256SUMS'
    if (-not (Test-Path -LiteralPath $manifest -PathType Leaf)) {
        throw 'Missing SHA256SUMS.'
    }
    $expected = [Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($line in [IO.File]::ReadAllLines($manifest)) {
        $match = [regex]::Match($line, '^([a-fA-F0-9]{64}) [ *](\./[^\r\n]+)$')
        if (-not $match.Success) { throw 'Invalid SHA256SUMS entry.' }
        $relative = $match.Groups[2].Value.Substring(2).Replace('/', '\')
        if ($relative -match '(^|\\)\.\.(\\|$)' -or $relative -match '[:*?"<>|]') {
            throw "Unsafe package path: $relative"
        }
        $file = [IO.Path]::GetFullPath((Join-Path $Source $relative))
        if (-not $file.StartsWith($Source.TrimEnd('\') + '\', [StringComparison]::OrdinalIgnoreCase)) {
            throw "Path escapes package: $relative"
        }
        if (-not $expected.Add($relative)) { throw "Duplicate package path: $relative" }
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing file: $relative" }
        $item = Get-Item -LiteralPath $file -Force
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse-point files are not allowed: $relative"
        }
        $actual = (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash
        if ($actual -ine $match.Groups[1].Value) { throw "SHA-256 mismatch: $relative" }
    }
    foreach ($dir in Get-ChildItem -LiteralPath $Source -Recurse -Force -Directory) {
        if (($dir.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse-point directory in package: $($dir.FullName)"
        }
    }
    foreach ($item in Get-ChildItem -LiteralPath $Source -Recurse -Force -File) {
        if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) {
            throw "Reparse point in package: $($item.FullName)"
        }
        $relative = $item.FullName.Substring($Source.TrimEnd('\').Length + 1)
        if ($relative -ine 'SHA256SUMS' -and -not $expected.Contains($relative)) {
            throw "Unlisted package file: $relative"
        }
    }
    if ($expected.Count -eq 0) { throw 'Empty SHA256SUMS.' }
    $binary = Join-Path $Source 'bin\devcontrol-agent.exe'
    $runner = Join-Path $Source 'scripts\run_next_windows_agent.ps1'
    foreach ($required in @($binary, $runner)) {
        if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
            throw "Required package file missing: $required"
        }
    }
    $binaries = @(Get-ChildItem -LiteralPath $Source -Recurse -File -Filter '*.exe')
    if ($binaries.Count -eq 0) { throw 'No Agent executable in package.' }
    if (-not $DevelopmentUnsigned) {
        # The signed CLI installer is the trust anchor for this local package.
        # Valid Authenticode signatures from unrelated publishers are not enough.
        $installer = Get-AuthenticodeSignature -LiteralPath $PSCommandPath
        if ($installer.Status -ne 'Valid' -or $null -eq $installer.SignerCertificate) {
            throw 'Windows production installer must have a valid Authenticode signature.'
        }
        $trustedThumbprint = $installer.SignerCertificate.Thumbprint
        $signedFiles = @($binaries) + @(Get-ChildItem -LiteralPath $Source -Recurse -File -Filter '*.ps1')
        foreach ($signed in $signedFiles) {
            $signature = Get-AuthenticodeSignature -LiteralPath $signed.FullName
            if ($signature.Status -ne 'Valid' -or $null -eq $signature.SignerCertificate -or
                $signature.SignerCertificate.Thumbprint -ine $trustedThumbprint) {
                throw "Untrusted Windows package signer: $($signed.Name) ($($signature.Status))"
            }
        }
    }
    return $binary
}
if ($Status) {
    if (Test-Path -LiteralPath $pointer) {
        $current = Get-Content -LiteralPath $pointer -Raw | ConvertFrom-Json
        Write-Output "RELEASE=$($current.release)"
    } else { Write-Output 'RELEASE=not-installed' }
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($null -eq $task) { Write-Output 'TASK=not-installed' }
    else { Write-Output "TASK=$($task.State)" }
    if (Test-Path -LiteralPath (Join-Path $stateDir 'enrollment.json')) {
        $enrollment = Get-Content -LiteralPath (Join-Path $stateDir 'enrollment.json') -Raw | ConvertFrom-Json
        Write-Output "DEVICE_ID=$($enrollment.device_id)"
    } else { Write-Output 'DEVICE_ID=pending' }
    exit 0
}
if ($Uninstall) {
    $task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($null -ne $task) {
        if ($task.State -eq 'Running') { Stop-ScheduledTask -TaskName $taskName }
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
    Write-Output "TASK=removed; files and device identity intentionally retained at $InstallRoot"
    exit 0
}
$GatewayUrl = $GatewayUrl.TrimEnd('/')
$parsedGateway = $null
if (-not [Uri]::TryCreate($GatewayUrl, [UriKind]::Absolute, [ref]$parsedGateway) -or
    $parsedGateway.Scheme -ne 'https' -or $parsedGateway.UserInfo -or
    $parsedGateway.Query -or $parsedGateway.Fragment -or
    $parsedGateway.AbsolutePath -ne '/') {
    throw 'GatewayUrl must be a clean HTTPS origin.'
}
# Fail closed: never enroll the Next installer with production's MCP.
if ($parsedGateway.Host -cne 'mcpx.devcontrol.dev' -or
    (-not $parsedGateway.IsDefaultPort) -or
    $parsedGateway.AbsoluteUri -cne 'https://mcpx.devcontrol.dev/') {
    throw 'DevControl Next Windows Agent requires its dedicated mcpx.devcontrol.dev Gateway.'
}
$expectedRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'devcontrol-next\Agent'))
$expectedRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'devcontrol-next\Agent'))
if (-not [string]::Equals($InstallRoot, $expectedRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw 'DevControl Next installer cannot write outside its dedicated installation root.'
}
$PackageDir = (Resolve-Path -LiteralPath $PackageDir).ProviderPath
$binary = Verify-Package $PackageDir
$versionLine = (& $binary --version | Out-String).Trim()
if ($LASTEXITCODE -ne 0 -or $versionLine -notmatch '^DevControl Next Agent ([0-9]+\.[0-9]+\.[0-9]+) \(([0-9a-f]{12,40})\)$') {
    throw "Invalid Agent release identity: $versionLine"
}
$release = "$($Matches[1])-$($Matches[2])"
$task = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
if ($null -ne $task) {
    if (Test-Path -LiteralPath $pointer) {
        $current = Get-Content -LiteralPath $pointer -Raw | ConvertFrom-Json
        if ($current.release -eq $release -and $current.gateway -eq $GatewayUrl) {
            Write-Output "WINDOWS_AGENT_ALREADY_INSTALLED release=$release task=$taskName"
            Write-Output "TASK=$($task.State)"
            exit 0
        }
    }
    throw 'Agent already installed. Version changes require a supervised update/rollback implementation.'
}
Lock-PrivateDirectory $InstallRoot
Lock-PrivateDirectory $stateDir
$releases = Join-Path $InstallRoot 'releases'
Lock-PrivateDirectory $releases
$releaseDir = Join-Path $releases $release
if (-not (Test-Path -LiteralPath $releaseDir)) {
    $staging = Join-Path $releases ('.incoming-' + [Guid]::NewGuid().ToString('N'))
    try {
        Copy-Item -LiteralPath $PackageDir -Destination $staging -Recurse
        $null = Verify-Package $staging
        Move-Item -LiteralPath $staging -Destination $releaseDir
    } finally {
        if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
    }
} else {
    $null = Verify-Package $releaseDir
}
$previous = if (Test-Path -LiteralPath $pointer) { [IO.File]::ReadAllText($pointer) } else { $null }
$config = @{ schema = 'devcontrol-next.windows-agent.v1'; release = $release; gateway = $GatewayUrl } | ConvertTo-Json -Compress
$tmpPointer = Join-Path $InstallRoot ('.current-' + [Guid]::NewGuid().ToString('N') + '.json')
[IO.File]::WriteAllText($tmpPointer, $config, (New-Object Text.UTF8Encoding($false)))
try {
    if (Test-Path -LiteralPath $pointer) {
        $backupPointer = Join-Path $InstallRoot 'current.backup.json'
        [IO.File]::Replace($tmpPointer, $pointer, $backupPointer)
    } else {
        Move-Item -LiteralPath $tmpPointer -Destination $pointer
    }
    $runnerPath = Join-Path $releaseDir 'scripts\run_next_windows_agent.ps1'
    $executionPolicy = if ($DevelopmentUnsigned) { 'Bypass' } else { 'RemoteSigned' }
    $arguments = '-NoLogo -NoProfile -NonInteractive -ExecutionPolicy ' + $executionPolicy + ' -File "' + $runnerPath + '" -InstallRoot "' + $InstallRoot + '"'
    $action = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Argument $arguments -WorkingDirectory $releaseDir
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User ([Security.Principal.WindowsIdentity]::GetCurrent().Name)
    $principal = New-ScheduledTaskPrincipal -UserId ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -LogonType Interactive -RunLevel Limited
    $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -MultipleInstances IgnoreNew -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -ExecutionTimeLimit ([TimeSpan]::Zero)
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null
    Start-ScheduledTask -TaskName $taskName
} catch {
    $failedTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($null -ne $failedTask) {
        Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
    }
    if ($null -ne $previous) { [IO.File]::WriteAllText($pointer, $previous) }
    elseif (Test-Path -LiteralPath $pointer) { Remove-Item -LiteralPath $pointer -Force }
    throw
}
Write-Output "WINDOWS_AGENT_INSTALL_ACCEPTED release=$release task=$taskName"
Write-Output 'ENROLLMENT=check DevControl device manager for this Windows device (approve if pending).'
Write-Output "STATUS=powershell -NoProfile -File $PSCommandPath -Status"
